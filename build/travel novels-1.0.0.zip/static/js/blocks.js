var $screenSm = 768, $screenMd = 935, $screenLg = 1170;




$(function () {
    $("[data-fancybox]").fancybox({
        smallBtn : 'false'
    });
});
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBhZ2UuanMiLCJoZWFkZXIuanMiLCJtb2RhbC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUNBOztBQ0RBOztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoiYmxvY2tzLmpzIiwic291cmNlc0NvbnRlbnQiOlsidmFyICRzY3JlZW5TbSA9IDc2OCwgJHNjcmVlbk1kID0gOTM1LCAkc2NyZWVuTGcgPSAxMTcwO1xuIiwiIiwiJChmdW5jdGlvbiAoKSB7XG4gICAgJChcIltkYXRhLWZhbmN5Ym94XVwiKS5mYW5jeWJveCh7XG4gICAgICAgIHNtYWxsQnRuIDogJ2ZhbHNlJ1xuICAgIH0pO1xufSk7Il19
